// Define the grid size and cell size
const GRID_SIZE = 50;
const CELL_SIZE = 10;
let startNode = null;
let endNode = null;


// Define the start and end points
let start, end;

// Define the grid
let grid = new Array(GRID_SIZE);
for (let i = 0; i < GRID_SIZE; i++) {
  grid[i] = new Array(GRID_SIZE);
}

// Define the open and closed sets
let openSet = [];
let closedSet = [];

// Define the path
let path = [];

function setup() {
  createCanvas(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE);
  
  // Set the start and end points
  start = grid[0][0] = new Node(0, 0);
  end = grid[GRID_SIZE - 1][GRID_SIZE - 1] = new Node(GRID_SIZE - 1, GRID_SIZE - 1);
  
  // Set the obstacles
  for (let i = 0; i < GRID_SIZE; i++) {
    for (let j = 0; j < GRID_SIZE; j++) {
      if (random() < 0.3 && grid[i][j] !== start && grid[i][j] !== end) {
        grid[i][j] = new Node(i, j, true);
      } else {
        grid[i][j] = new Node(i, j, false);
      }
    }
  }
  
  // Add the start node to the open set
  openSet.push(start);
}

function draw() {
  if (startNode) {
    fill(0, 255, 0);
    rect(startNode.x * CELL_SIZE, startNode.y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
  }
  if (endNode) {
    fill(255, 0, 0);
    rect(endNode.x * CELL_SIZE, endNode.y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
  }
  // If the open set is empty, the path does not exist
  if (openSet.length > 0) {
    // Find the node in the open set with the lowest f score
    let lowestFIndex = 0;
    for (let i = 0; i < openSet.length; i++) {
      if (openSet[i].f < openSet[lowestFIndex].f) {
        lowestFIndex = i;
      }
    }
    let current = openSet[lowestFIndex];
    
    // If the current node is the end node, the path has been found
    if (current === end) {
      // Reconstruct the path
      let temp = current;
      path.push(temp);
      while (temp.previous) {
        path.push(temp.previous);
        temp = temp.previous;
      }
      noLoop();
      console.log("Path found!");
    }
    
    // Move the current node from the open set to the closed set
    openSet.splice(lowestFIndex, 1);
    closedSet.push(current);
    
    // Check the neighbors of the current node
    let neighbors = current.neighbors();
    for (let i = 0; i < neighbors.length; i++) {
      let neighbor = neighbors[i];
      
      // Ignore neighbors in the closed set or obstacles
      if (!closedSet.includes(neighbor) && !neighbor.obstacle) {
        // Calculate the tentative g score
        let tentativeG = current.g + 1;
        
        // If the neighbor is not in the open set, add it
        if (!openSet.includes(neighbor)) {
          openSet.push(neighbor);
        } else if (tentativeG >= neighbor.g) {
          // If the neighbor is already in the open set and the tentative g score is not better, skip it
          continue;
        }
        
        // Update the neighbor's g, h, and f scores and set the current node as its previous node
        neighbor.g = tentativeG;
        neighbor.h = heuristic(neighbor, end);
        neighbor.f = neighbor
        neighbor.previous = current;
      }
    }
  } else {
    // If the open set is empty and the path has not been found, it does not exist
    console.log("Path does not exist!");
    noLoop();
  }
  
  // Draw the grid
  for (let i = 0; i < GRID_SIZE; i++) {
    for (let j = 0; j < GRID_SIZE; j++) {
      if (grid[i][j].obstacle) {
        fill(0);
      } else if (openSet.includes(grid[i][j])) {
        fill(0, 255, 0);
      } else if (closedSet.includes(grid[i][j])) {
        fill(255, 0, 0);
      } else if (path.includes(grid[i][j])) {
        fill(0, 0, 255);
      } else {
        fill(255);
      }
      stroke(0);
      rect(i * CELL_SIZE, j * CELL_SIZE, CELL_SIZE, CELL_SIZE);
    }
  }
}

function heuristic(a, b) {
  // Calculate the Euclidean distance between nodes a and b
  let dx = abs(a.x - b.x);
  let dy = abs(a.y - b.y);
  return sqrt(dx * dx + dy * dy);
}

class Node {
  constructor(x, y, obstacle = false) {
    this.x = x;
    this.y = y;
    this.obstacle = obstacle;
    this.g = Infinity;
    this.h = 0;
    this.f = Infinity;
    this.previous = null;
  }
  
  neighbors() {
    // Return the neighbors of this node
    let result = [];
    for (let i = -1; i <= 1; i++) {
      for (let j = -1; j <= 1; j++) {
        if (i === 0 && j === 0) {
          continue;
        }
        let x = this.x + i;
        let y = this.y + j;
        if (x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE) {
          result.push(grid[x][y]);
        }
      }
    }
    return result;
  }
}

function mousePressed() {
  if (mouseX >= 0 && mouseX < width && mouseY >= 0 && mouseY < height) {
    let i = floor(mouseX / CELL_SIZE);
    let j = floor(mouseY / CELL_SIZE);
    let node = grid[i][j];
    if (node.obstacle) {
      node.obstacle = false;
    } else if (!startNode) {
      startNode = node;
      startNode.obstacle = false;
    } else if (!endNode) {
      endNode = node;
      endNode.obstacle = false;
    } else {
      node.obstacle = true;
    }
  }
}

